package com.lyj.securitydomo.repository.search;

public interface PostSearch {
}