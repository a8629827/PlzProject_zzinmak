package com.lyj.securitydomo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityDomoApplicationTests {

    @Test
    void contextLoads() {
    }

}
