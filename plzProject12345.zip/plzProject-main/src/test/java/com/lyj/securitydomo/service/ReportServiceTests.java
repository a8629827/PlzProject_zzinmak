package com.lyj.securitydomo.service;

import groovy.util.logging.Log4j2;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@Slf4j
@SpringBootTest
@Log4j2
public class ReportServiceTests {
    @Autowired
    private ReportService reportService;
    @Test
    public void testRegister() {
    log.info(reportService.getClass().getName());
}}

