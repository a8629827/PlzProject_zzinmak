package com.lyj.securitydomo.service;

public class UserDetailService {
}
