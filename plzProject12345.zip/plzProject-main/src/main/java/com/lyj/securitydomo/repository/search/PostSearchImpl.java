package com.lyj.securitydomo.repository.search;

public class PostSearchImpl {
}
